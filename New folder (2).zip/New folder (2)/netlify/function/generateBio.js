const axios = require('axios');

exports.handler = async function(event, context) {
  try {
    const { prompt, style, type } = JSON.parse(event.body);
    const apiKey = process.env.OPENROUTER_API_KEY;
    
    // Validate request
    if (!prompt || !style || !type) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing required parameters" })
      };
    }
    
    // Prepare the AI model based on request type
    let model = "deepseek/deepseek-chat-v3-0324:free";
    let messages = [{ role: "user", content: prompt }];
    
    // Make API call to OpenRouter
    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model,
      messages
    }, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://your-site.netlify.app',
        'X-Title': 'InstaGen Pro Tool'
      }
    });

    return {
      statusCode: 200,
      body: JSON.stringify({
        bio: response.data.choices[0].message.content
      })
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: error.message,
        fullError: error.response?.data 
      })
    };
  }
};